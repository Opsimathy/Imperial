function omrhs = Buoyancy(T) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                       %
% compute buoyancy term essentially T_x %
% Periodic in x                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen
  global yLen
  global Ra 
  global Pr 

  N = size(T,1);
  M = size(T,2); 
  dx = xLen/(N); 
  dy = yLen/(M-1); 

  T = bc_T(T,1);
  omrhs = zeros(N,M); 
  Tx = zeros(N,M);    

  % Horizontal temperature gradient
  Tx(2:N-1,:) = ( T(3:N,:) - T(1:N-2,:) )/(2*dx);
  Tx(1,:)=(T(2,:)-T(N,:))/(2*dx);
  Tx(N,:)=(T(1,:)-T(N-1,:))/(2*dx);
  % buoyancy term 
  omrhs = Ra*Pr*Tx; 
