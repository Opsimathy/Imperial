function Tout = GS_T(Tin,b,dt,Niter,bcflag)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                        %
%    Takes Niter GS sweeps for           %
%    the diffusion equation for T        %
%                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen
  global yLen

  N = size(b,1);
  M = size(b,2);
  dx = xLen/(N);
  dy = yLen/(M-1);

  % coefficients for diffusion equation
  rx = dt/dx/dx/2;
  ry = dt/dy/dy/2;
  r0 = 1 + 2*(rx + ry); 

  T = Tin;

  % implement boundary conditons
  T = bc_T(T,bcflag);

  for k=1:Niter
    for i=1:N
        im=i-1;ip=i+1;
        if(im==0)im=N;end
        if(ip==N+1)ip=1;end
      for j=2:M-1
	T(i,j) = (rx*(T(ip,j)+T(im,j)) + ...
	          ry*(T(i,j+1)+T(i,j-1)) +  b(i,j))/r0;
      end
    end
    T = bc_T(T,bcflag);
  end

  Tout = T;
  