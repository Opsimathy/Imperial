function Aout = MultigridV_psi(Ain,f)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                          %
% Multigrid V-cycle for delsqr(psi)=f                      %
%                                                          %
% (recursive definition)                                   %
% (dimension N has to be of the form 2^k or M=2^k+1)       %
%                                                          %
% Ain:  guessed solution (N x M)-matrix                    %
% f:    right-hand side (N x M)-matrix                     %
%                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    n = size(f,1); 
    m = size(f,2);  

% if we are at the coarsest level
    if ((n==2)|(m==3)) 
      Aout = GS_psi(Ain,f,10); 
    else
% else

%     relax 10 times (pre-smoothing)
      Asmooth = GS_psi(Ain,f,10); 

%     compute the residual
      res  = residual_psi(Asmooth,f); 

%     restrict the residual to the next-coarser grid
      res2 = restrict(res); 
      res2 = bc_psi(res2);

%     solve the error equation on the next-coarser grid by MGV
      err = MultigridV_psi(zeros(size(res2)),res2); 

%     add the interpolated error to the solution 
      err = bc_psi(err);
      Asmooth = Asmooth + interp(err); 

%     relax 10 times (post-smoothing) 
      Aout = GS_psi(Asmooth,f,10);

    end

    % impose boundary conditions
    Aout = bc_psi(Aout);
