function T=Tinit(T)
%
% A small x-dependent perturbation of T to kickstart instabilities
%
global xLen
global yLen

N=size(T,1);
M=size(T,2);
dx=xLen/N;
dy=yLen/(M-1);

for i=1:N
    x=dx*(i-1);
    for j=1:M
        y=dy*(j-1);
        %T(i,j)=.01*x*(xLen-x)*y*(yLen-y);
        T(i,j)=.01*sin(pi*x)*sin(pi*y);
     end
    end
    