function T = bc_T(T,bcflag); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
% implement Dirichlet/periodic boundary conditions for Temperature   
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  N  = size(T,1);
  M  = size(T,2);

  for i=1:N
  T(i,1) = bcflag; % if bcflag=1 impose heated bottom T=1, otherwise T=0
  end
  T(:,M) = 0; % cold top


