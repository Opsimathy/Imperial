function u = bc_U(u); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                           %
% implement Dirichlet boundary conditions   %
% (for u-velocity)                          % 
%                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  N  = size(u,1);
  M  = size(u,2);


  u(:,1) = 0;
  u(:,M) = 0;
