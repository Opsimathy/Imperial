function psi = bc_psi(psi); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% implement homogeneous Dirichlet/periodic boundary conditions  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  N  = size(psi,1);
  M  = size(psi,2);

  psi(:,1) = 0;
  psi(:,M) = 0;
  
