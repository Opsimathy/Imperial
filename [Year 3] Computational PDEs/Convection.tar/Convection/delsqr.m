function delsqrpsi = delsqr(psi)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calculates Laplacian                    %
%   -omega = Laplacian of psi               %
%    Dirichlet in M, periodic in N (x)      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen
  global yLen

  N = size(psi,1);
  M = size(psi,2);
  dx = xLen/(N);
  dy = yLen/(M-1);

  delsqrpsi=zeros(N,M);
  
  rx = 1/dx/dx;
  ry = 1/dy/dy;
  r0 = 2*(rx + ry); 

    for i=1:N
        im=i-1;ip=i+1;
        if(im==0) im=N; end
        if(ip==N+1) ip=1; end
      for j=2:M-1
	     delsqrpsi(i,j) = (rx*(psi(ip,j)+psi(im,j)) + ...
	          ry*(psi(i,j+1)+psi(i,j-1)) -r0*psi(i,j));
      end
    end
  