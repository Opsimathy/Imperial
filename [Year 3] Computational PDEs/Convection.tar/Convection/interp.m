function fine = interp(coarse)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                   %
%  interpolation routine (inverse full weighting)   % 
%   Note M isn't the dimension of the array here    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   [r,c] = size(coarse);
   N = r;
   M = c-1; 
   N2 = 2*N;
   M2 = 2*M; 

   fine = zeros(N2,M2+1);
% Take averages of nearest neighbours (periodic in x)
   fine(3:2:N2-1,3:2:M2-1) =  coarse(2:N,2:M); 
   fine(3:2:N2-1,2:2:M2)   = (coarse(2:N,1:M) + coarse(2:N,2:M+1))/2;
   fine(2:2:N2-2,3:2:M2-1) = (coarse(1:N-1,2:M) + coarse(2:N,2:M))/2;
       fine(N2  ,3:2:M2-1) = (coarse(N,2:M) + coarse(1,2:M))/2;
   fine(2:2:N2-2,2:2:M2)   = (coarse(1:N-1,1:M) + coarse(2:N,2:M+1) + ...
                               coarse(2:N,1:M) + coarse(1:N-1,2:M+1) )/4;
       fine(N2  ,2:2:M2)   = (coarse(N,1:M) + coarse(1,2:M+1) + ...
                               coarse(1,1:M) + coarse(N,2:M+1) )/4; 
     
    