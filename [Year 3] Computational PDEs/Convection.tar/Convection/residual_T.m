function res = residual_T(T,f,dt,bcflag) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       %
%  Residual for T_t=delsqr(T) using Crank-Nicolson      %
%  if bcflag=1, use full bcs; otherwise homogeneous     %
%                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   global xLen
   global yLen 

   N = size(f,1);
   M = size(f,2);
   dx = xLen/(N);
   dy = yLen/(M-1);

   % coefficients for the diffusion equation
   rx = dt/dx/dx/2;
   ry = dt/dy/dy/2;
   r0 = 1 + 2*(rx + ry); 

   % impose boundary conditions
   T = bc_T(T,bcflag);

   % residual res=f-delsqr(T)
   res = zeros(size(T));
   for i=1:N
       im=i-1;ip=i+1;
       if(im==0)im=N;end
       if(ip==N+1)ip=1;end
   res(i,2:M-1) = f(i,2:M-1) - ...
                      T(i,2:M-1)*r0 + ... 
                     (T(i,3:M) + T(i,1:M-2))*ry + ... 
                     (T(ip,2:M-1) + T(im,2:M-1))*rx; 
   end


