function res = residual_psi(Ain,f) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                              %
%  residual routine for Psi Poisson equation   %
%                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   global xLen
   global yLen 

   N = size(f,1);
   M = size(f,2);
   dx = xLen/(N);
   dy = yLen/(M-1);

   % coefficients for the Poisson equation
   rx = 1/dx/dx;
   ry = 1/dy/dy;
   r0 = 2*(rx + ry); 

   % implement boundary conditions
   Ain = bc_psi(Ain);

   % residual computation; periodic in x
   res = zeros(size(Ain)); 
   for i=1:N
       im=i-1;ip=i+1;
       if(im==0)im=N;end
       if(ip==N+1)ip=1;end
           
   res(i,2:M-1) = f(i,2:M-1) + ...
                      Ain(i,2:M-1)*r0 - ... 
                     (Ain(i,3:M) + Ain(i,1:M-2))*ry - ... 
                     (Ain(ip,2:M-1) + Ain(im,2:M-1))*rx;
   end



