%==========================================
%
%   Advection-Diffusion of heat for given velocity field.
%
%   (using fractional-step method)
%
%   streamfunction-vorticity formulation
%
%==========================================

   clear

   % global variables
   global xLen  
   global yLen
   global Ra
   global Pr

   % domain and grid size (Length of 1 should be 2^k + 2) 
   xLen =  5; 
   yLen =  1;
   m    = 17; 
   n    = xLen*(m-1)   

   % parameters (Rayleigh number, Prandtl number, Reynolds number)
   Ra   =  10000;
   Pr   =    0.7;
   Re   =3000;

   dx    = xLen/(n); 
   dy    = yLen/(m-1); 
   dt    = 0.005*min(dx,dy);
   tstep = 2000;  % number of time-steps 
   
   % initializations
   u  = zeros(n,m); 
   v  = zeros(n,m);
   T  = zeros(n,m); 
   psi= zeros(n,m); 
   omega = zeros(n,m);
   for iblob=1:5
       omega=blob(omega,(iblob-1)*xLen/5+.5,.5,.2,(-1)^iblob*Re);
   end
   psirhs = -omega;   
   psi = PsiEqu(psi,psirhs);  
   [u,v] = velo(psi);
   
   % domain for graphical output
   x  = linspace(dx/2,xLen-dx/2,n-2);
   y  = linspace(dy/2,yLen-dy/2,m-2).';
   [xx,yy] = meshgrid(x,y);
   % Velocity vector plot 
       figure(1) 
       quiver(xx(1:end,1:end)',yy(1:end,1:end)',... 
              u(2:n-1,2:m-1),v(2:n-1,2:m-1),1);
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);

   %
   % Let's do the the time loop again
   %
   for i=1:tstep
     fprintf('time step %i out of %i\n',i,tstep)

     % advection step for temperature  
     Tadv  = advect(u,v,T,dt);
     
     % diffusion step for temperature 
     Tnew  = Diffuse_T(Tadv,dt);
  
     % One day include advection step for vorticity
     %omadv = advect(u,v,om,dt);

     % and diffusion step for vorticity 
     %omdiff = DiffOm(omadv,omrhs,Psi,dt);  
     
     % streamfunction Poisson equation
     %psirhs = -omega;   
     %psinew = PsiEqu(psi,psirhs);  

     % Derive the velocity field from the streamfunction
     %[unew,vnew] = velo(psinew);

     % update all fields
     %u = unew; 
     %v = vnew; 
     %omega = omdiff; 
     T  = Tnew; 
     %psi = psinew;

     % determine the maximum velocity (for CFL condition)
     umax = max(max(abs(u(2:n-1,2:m-1))));
     vmax = max(max(abs(v(2:n-1,2:m-1))));
     velmax = max(1,max(umax,vmax));
     dtCFL = 0.8*min(dx,dy)/velmax;     % CFL = 0.8
     if(dt>dtCFL)
         fprintf('Dangerous CFL\n');
     end
          % Contour every 25 steps
          
     if ((mod(i,25)==0)|(i==1)) 

      % % Velocity vector plot 
      % figure(1) 
       %quiver(xx(1:end,1:end)',yy(1:end,1:end)',... 
        %      u(2:n-1,2:m-1),v(2:n-1,2:m-1),1);
       %xis image
       %axis([0 xLen 0 yLen])
       %xlabel('x','FontSize',18)
       %ylabel('y','FontSize',18);

       %  Temperature contours (isotherms) 
       figure(2) 
       contourf(xx',yy',T(2:n-1,2:m-1),10,'r')
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);
       
       drawnow
     end
   end
