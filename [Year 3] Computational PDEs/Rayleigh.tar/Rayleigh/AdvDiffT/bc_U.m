function u = bc_U(u); 

%===========================================
%
% implement Dirichlet boundary conditions
% (for u-velocity)
%
%===========================================

  n  = size(u,1);
  m  = size(u,2);

  % ghost cell mapping
  u(1,:) = -u(2,:);
  u(n,:) = -u(n-1,:);
  u(:,1) = -u(:,2);
  u(:,m) = -u(:,m-1);

  % corner elements 
  u(1,1) = (u(1,2)+u(2,1))/2; 
  u(n,1) = (u(n-1,1)+u(n,2))/2;
  u(1,m) = (u(1,m-1)+u(2,m))/2;
  u(n,m) = (u(n-1,m)+u(n,m-1))/2;
