function v = bc_V(v); 

%===========================================
%
% implement Dirichlet boundary conditions
% (for u-velocity)
%
%===========================================

  % resolution
  n  = size(v,1);
  m  = size(v,2);

  % ghost cell mapping
  v(1,:) = -v(2,:);
  v(n,:) = -v(n-1,:);
  v(:,1) = -v(:,2);
  v(:,m) = -v(:,m-1);

  % corner elements
  v(1,1) = (v(1,2)+v(2,1))/2; 
  v(n,1) = (v(n-1,1)+v(n,2))/2;
  v(1,m) = (v(1,m-1)+v(2,m))/2;
  v(n,m) = (v(n-1,m)+v(n,m-1))/2;
