function [ux,vx,uy,vy] = bc_flux_vel(ux,vx,uy,vy); 

%===========================================
%
% implement Dirichlet boundary conditions for 
% flux velocities
%
%===========================================

  global xLen 
  global yLen 

  % resolution
  n  = size(ux,1);
  m  = size(ux,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % ghost cell mapping for ux
  ux(2,:) = 0;
  ux(n,:) = 0; 
  ux(:,1) = -ux(:,2);
  ux(:,m) = -ux(:,m-1);

  % ghost cell mapping for vx
  vx(2,:) = 0;
  vx(n,:) = 0; 
  vx(:,1) = -vx(:,2);
  vx(:,m) = -vx(:,m-1);

  % ghost cell mapping for uy
  uy(1,:) = -uy(2,:);
  uy(n,:) = -uy(n-1,:); 
  uy(:,2) = 0;
  uy(:,m) = 0;

  % ghost cell mapping for vy
  vy(1,:) = -vy(2,:);
  vy(n,:) = -vy(n-1,:); 
  vy(:,2) = 0;
  vy(:,m) = 0;
