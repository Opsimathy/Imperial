 function omegaout=blob(omegain,xc,yc,radius,strength)
 global xLen  
 global yLen
 N=size(omegain,1);
 M=size(omegain,2);
 dx=xLen/(N-2);dy=yLen/(M-2);
 for i=1:N
     for j=1:M
         x=dx*(i-1);
         y=dy*(j-1);
         r = min(sqrt( (x-xc)^2 + (y-yc)^2),radius)/radius;
         omegaout(i,j)=omegain(i,j)+ strength*(1 + cos(pi*r))/4;
     end
 end