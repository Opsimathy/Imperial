function delsqrpsi = delsqr(psi)

%=============================================
%
%   -omega = Laplacian of psi 
%
%=============================================

  global xLen
  global yLen

  n = size(psi,1);
  m = size(psi,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  delsqrpsi=zeros(n,m);
  
  % coefficients for diffusion equation
  rx = 1/dx/dx;
  ry = 1/dy/dy;
  r0 = 2*(rx + ry); 

    for i=2:n-1
      for j=2:m-1
	delsqrpsi(i,j) = (rx*(psi(i+1,j)+psi(i-1,j)) + ...
	          ry*(psi(i,j+1)+psi(i,j-1)) + ...
	         -r0*psi(i,j));
      end
    end
  