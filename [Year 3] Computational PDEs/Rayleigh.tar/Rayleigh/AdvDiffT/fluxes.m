function [deladd,fadd,gadd1,gadd2] = fluxes(q,u,v,dx,dt)

%========================================================
%
% routine computes fluxes along a single 
% grid line in the x or y direction
%
% output: deladd (increment to add to cell i)
%         fadd (new contribution to the flux at the "left" edge)
%         gadd1 (contribution to the flux in the other direction
%                in the cell "below" this cell)
%         gadd2 (contribution to the flux in the other direction
%                  in the cell "above" this cell)
%
%========================================================

   % resolution
   n = length(q);

   % initialization
   deladd = zeros(n,1);
   fadd   = zeros(n,1);
   gadd1  = zeros(n,1);
   gadd2  = zeros(n,1);

   for i=2:n
     dq(i) = q(i) - q(i-1); 
     if (u(i) > 0)                    
       j = i; % rightward going wave 
     else
       j = i-1; % leftward going wave
     end
     deladd(j) = deladd(j) + u(i)*dq(i);

     % corrections for transverse propagation of dq
     if (v(i) > 0) 
       %  upward
       gadd2(j) = gadd2(j) - dt/dx/2*u(i)*v(i)*dq(i);
     else
       %  downward
       gadd1(j) = gadd1(j) - dt/dx/2*u(i)*v(i)*dq(i);
     end
   end

   %  modify F fluxes for second order u_{xx} terms
   for i=2:n-1
     fincr = abs(u(i))/2*(1 - abs(u(i))*dt/dx)*dq(i);
     fadd(i) = fadd(i) + fincr; 

     %     compute fraction of dq that goes into adjacent row
     %     (transverse propagation of second order correction waves)

     fract = abs(v(i))*dt/dx*fincr;
     if (v(i) < 0) 
       %    downward
       gadd1(i) = gadd1(i) - fract;
       gadd1(i-1) = gadd1(i-1) + fract;
     else
       %    upward
       gadd2(i) = gadd2(i) + fract;
       gadd2(i-1) = gadd2(i-1) - fract;
     end
   end
