function res = residual_T(T,f,dt,bcflag) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       %
%  residual for T_t=delsqr(T) using Crank-Nicolson      %
%  if bcflag=1, use full bcs; otherwise homogeneous     %
%                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   global xLen
   global yLen 

   n = size(f,1);
   m = size(f,2);
   dx = xLen/(n-2);
   dy = yLen/(m-2);

   % coefficients for the diffusion equation
   rx = dt/dx/dx/2;
   ry = dt/dy/dy/2;
   r0 = 1 + 2*(rx + ry); 

   % impose boundary conditions
   T = bc_T(T,bcflag);

   % residual res=f-delsqr(T)
   res = zeros(size(T)); 
   res(2:n-1,2:m-1) = f(2:n-1,2:m-1) - ...
                      T(2:n-1,2:m-1)*r0 + ... 
                     (T(2:n-1,3:m) + T(2:n-1,1:m-2))*ry + ... 
                     (T(3:n,2:m-1) + T(1:n-2,2:m-1))*rx; 



