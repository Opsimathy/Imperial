function Acoarse = restrict(Afine) 

%=====================================================
%
%  restriction routine (for cell-centered quantities) 
%
%=====================================================

   % resolution
   r = size(Afine,1);
   c = size(Afine,2);
   n = r-2;
   m = c-2; 
   n2 = n/2;
   m2 = m/2;

   Acoarse = zeros(n2+2,m2+2); 

   % restriction operation
   for i=2:n2+1
     for j=2:m2+1
       Acoarse(i,j) = (Afine(2*i-2,2*j-2) + ...
	               Afine(2*i-1,2*j-2) + ... 
	               Afine(2*i-2,2*j-1) + ... 
	               Afine(2*i-1,2*j-1))/4; 
     end
   end
