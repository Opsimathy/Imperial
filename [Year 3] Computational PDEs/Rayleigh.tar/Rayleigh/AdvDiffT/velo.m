function [u,v] = velo(psi);

%===========================================
%
%  routine computes the velocity field 
%  from the streamfunction
%
%===========================================

  global xLen 
  global yLen 

  % resolution
  n = size(psi,1);
  m = size(psi,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % u= psi_y
  u = zeros(n,m);
  u(:,2:m-1) = ( psi(:,3:m) - psi(:,1:m-2) )/(2*dy);

  % v=-psi_x
  v = zeros(n,m);
  v(2:n-1,:) = ( psi(1:n-2,:) - psi(3:n,:) )/(2*dx);

  % impose boundary conditions
  u = bc_U(u);
  v = bc_V(v);
  