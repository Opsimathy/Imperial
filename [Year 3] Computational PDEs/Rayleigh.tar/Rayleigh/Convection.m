%==========================================
%
%   Euler equations
%   in a rectangular domain 
%
%   
%
%   streamfunction-vorticity formulation
%
%==========================================

   clear

   
   global xLen  
   global yLen
   global Pr
   
   % box size and resolution (should be 2^k + 2) 
   xLen =  1; 
   yLen =  1;
   Pr=.5;
   N    = 34; 
   M    = 34;     

   % derived parameters
   dx    = xLen/(N-2); 
   dy    = yLen/(M-2); 
   dt    = 0.005*min(dx,dy);
   tstep = 2500;  % number of time-steps 
  
   u  = zeros(N,M); unew=zeros(N,M);
   v  = zeros(N,M); vnew=zeros(N,M);
   psi= zeros(N,M); 
   om = zeros(N,M);
   omrhs=zeros(N,M);
   for i=1:N
    for j=1:M
        x=dx*(i-1);
      %  xp=x+.5*dx;
        y=dy*(j-1);
       % yp=y+.5*dy;
        cx=cos(2*pi*x);% cxp=cos(2*pi*xp);
      cy=cos(2*pi*y); %cyp=cos(2*pi*yp);
      om(i,j)=10*(x*(1-cy)+cy*(1-cx));
      %if i<N if j< M omegapp(i,j)=cxp*(1-cyp)+cyp*(1-cxp);end;end;
       r1 = min(sqrt( (x-0.75)^2 + (y-0.5)^2),0.2)/0.2; 
       r2 = min(sqrt( (x-0.25)^2 + (y-0.25)^2),0.2)/0.2;
       %rpp = min(sqrt( (xp-0.5)^2 + (yp-0.75)^2),0.2)/0.2; 
      % omega(i,j) =(1 + cos(pi*r))/4;
       %omegapp(i,j)=(1 + cos(pi*rpp))/4;
      % blob=45;
       om(i,j)=om(i,j)+ 30*(1 + cos(pi*r1))/4 - 30*(1 + cos(pi*r2))/4;
       %if i<N if j< M omegapp(i,j)=omegapp(i,j)+ blob *(1 + cos(pi*rpp))/4;end;end;
    end
   end

   % Let's do the time loop again
   %
   for i=1:tstep
     fprintf('time step %i out of %i\n',i,tstep)

     % advection step for vorticity
     %omadv=om;
     omadv = advect(u,v,om,dt);
    
     % diffusion step for vorticity 
     omnew = DiffOm(omadv,omrhs,psi,dt);  
  
     % streamfunction delsqr(psi)=-omega
     psirhs = -omnew;   
     psinew = PsiEqu(psi,psirhs);  

     % Calculate velocity components from psi
     [unew,vnew] = velo(psinew);

     % update all fields
     u = unew; 
     v = vnew; 
     om = omnew; 
     psi = psinew;

     % determine the maximum velocity (for CFL condition)
     umax = max(max(abs(u(2:N-1,2:M-1))));
     vmax = max(max(abs(v(2:N-1,2:M-1))));
     velmax = max(1,max(umax,vmax));
     dtCFL = 0.8*min(dx,dy)/velmax;     % CFL = 0.8
     if(dt>dtCFL)
         fprintf('Courant condition CFL\n');
     end
         
     % Plots every 25 steps
  % domain for graphical output
   x  = linspace(dx/2,xLen-dx/2,N-2);
   y  = linspace(dy/2,yLen-dy/2,M-2).';
   [xx,yy] = meshgrid(x,y);

     if ((mod(i,25)==0)|(i==1)) 

       figure(1) 
      % quiver(xx(1:end,1:end)',yy(1:end,1:end)',... 
        %      u(2:n-1,2:m-1),v(2:n-1,2:m-1),1);
      % axis image
       %axis([0 xLen 0 yLen])
       %xlabel('x','FontSize',18)
       %ylabel('y','FontSize',18);
 
       contourf(xx',yy',om(2:N-1,2:M-1),20,'r')
       colorbar
       figure(2) 
       contourf(xx',yy',psi(2:N-1,2:M-1),20,'r')
        colorbar
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);
       
       drawnow
     end
   end
