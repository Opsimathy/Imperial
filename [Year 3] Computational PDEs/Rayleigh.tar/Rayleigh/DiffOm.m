function omnew = DiffOm(omold,omrhs,psi,dt) 

%=======================================
%
% solve for a diffusion step for the 
% new vorticity (Implicit, uses Crank-Nicolson)
%
%=======================================
  global Pr;
  
  om  = omold;         % use previous vorticity as initial guess 
  n  = size(omold,1); 
  m  = size(omold,2); 

  rhs = omold+dt*omrhs+0.5*dt*Pr*delsqr(omold);  % possibly include rotational forcing (omrhs)
 
  rm = 1;
  while (rm > 1e-7)
    om = MultigridV_om(om,rhs,psi,dt,n);
    res = residual_om(om,rhs,psi,dt,1); 
    rm = max(max(abs(res(2:n-1,2:m-1))));
  end
  om = bc_Om(om,psi,1);  % impose boundary conditions 
  omnew = om;            % update vorticity field 

