function omnew = DiffOm(omold,omrhs,Psi,dt) 

%=======================================
%
% solve a diffusion problem for the 
% new vorticity (implicit; backward Euler)
%
%=======================================
  global Pr;
  
  om  = omold;         % use previous field as initial guess 
  n  = size(omold,1); 
  m  = size(omold,2); 

  rhs = omold+dt*omrhs+0.5*dt*Pr*laplacien(omold);  % add buoyancy term (omrhs)
 
  rm = 1;
  while (rm > 1e-9)
    om = MGV_Diff_Om(om,rhs,Psi,dt,n);
    r = residual_Diff_Om(om,rhs,Psi,dt,1); 
    rm = max(max(abs(r(2:n-1,2:m-1))));
  end
  om = bc_Om(om,Psi,1);  % impose boundary conditions 
  omnew = om;            % update vorticity field 

