function Aout = GS_T(Ain,b,dt,Niter,bcflag)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                        %
%    Takes Niter GS sweeps for           %
%    the diffusion equation for T        %
%                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen
  global yLen

  % resolution
  n = size(b,1);
  m = size(b,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % coefficients for diffusion equation
  rx = dt/dx/dx/2;
  ry = dt/dy/dy/2;
  r0 = 1 + 2*(rx + ry); 

  % initialization
  T = Ain;

  % implement boundary conditons
  T = bc_T(T,bcflag);

  % iteration
  for k=1:Niter
    for i=2:n-1
      for j=2:m-1
	T(i,j) = (rx*(T(i+1,j)+T(i-1,j)) + ...
	          ry*(T(i,j+1)+T(i,j-1)) + ...
	          b(i,j))/r0;
      end
    end
    T = bc_T(T,bcflag);
  end

  Aout = T;
  