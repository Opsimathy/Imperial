function omout = GS_om(omin,b,psi,dt,ktimes,bcflag)

%=============================================
%
%    solves the diffusion equation for omega 
%    using Gauss-Seidel
%
%=============================================

  global xLen
  global yLen
  global Pr

  % resolution
  n = size(b,1);
  m = size(b,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % coefficients for diffusion equation
  rx = Pr*dt/dx/dx/2;
  ry = Pr*dt/dy/dy/2;
  r0 = 1 + 2*(rx + ry); 

  % initialization
  u = omin;

  % implement boundary conditons
  u = bc_Om(u,psi,bcflag);

  % iteration
  for k=1:ktimes
    for i=2:n-1
      for j=2:m-1
	u(i,j) = (rx*(u(i+1,j)+u(i-1,j)) + ...
	          ry*(u(i,j+1)+u(i,j-1)) + ...
	          b(i,j))/r0;
      end
    end
    u = bc_Om(u,psi,bcflag);
  end

  omout = u;
  