function psiout = GS_psi(psiin,f,Niter)

%===========================================
% 
% Takes Niter Gauss-Seidel sweeps for
% delsqr(psi)=f
%===========================================

  global xLen 
  global yLen

  n = size(f,1);
  m = size(f,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % coefficients for Poisson equation
  rx = 1/dx/dx;
  ry = 1/dy/dy;
  r0 = 2*(rx + ry); 

  % initialization
  psi = psiin;

  % implement boundary conditons
  psi = bc_Psi(psi);

  % iteration
  for k=1:Niter
    for i=2:n-1
      for j=2:m-1
	psi(i,j) = (rx*(psi(i+1,j)+psi(i-1,j)) + ...
	           ry*(psi(i,j+1)+psi(i,j-1)) - ...
	           f(i,j))/r0;
      end
    end
    psi = bc_Psi(psi);
  end

  psiout = psi;
  