function Aout = MGV_Diff_Om(Ain,f,Psi,dt,nmax)

%------------------------------------------------------------------
% geometric multigrid V-cycle for Diffusion equation
%
% (recursive definition) 
% (dimension N has to be of the form 2^k + 2) 
%
% Ain:  guessed solution (n x m)-matrix
% f:    right-hand side (n x m)-matrix
% p:    pressure (needed for boundary conditions) 
% dt:   time-step 
% nmax: resolution at maximum level
%
%------------------------------------------------------------------

    n = size(f,1); 
    m = size(f,2);  

    if (n == nmax)     % set the boundary condition flag 
      bcflag = 1;      % for top level equations (inhomogeneous)
    else
      bcflag = 0;      % for error equations (homogeneous)
    end

% if we are at the coarsest level
    if ((n==4)|(m==4)) 
      Aout = relax_Diff_Om(Ain,f,Psi,dt,10,bcflag); 
    else
% otherwise

%     relax 10 times (pre-smoothing)
      Asmooth = relax_Diff_Om(Ain,f,Psi,dt,10,bcflag); 

%     compute the residual
      res  = residual_Diff_Om(Asmooth,f,Psi,dt,bcflag); 

%     restrict the residual and the pressure to the next-coarser grid
      res2 = restrict(res); 
      Psi2 = restrict(Psi);
      res2 = bc_Om(res2,Psi2,0);

%     solve the error equation on the next-coarser grid by MGV
      err = MGV_Diff_Om(zeros(size(res2)),res2,Psi2,dt,nmax); 

%     add the prolongated error to the solution 
      err = bc_Om(err,Psi2,0);
      Asmooth = Asmooth + prolong(err); 

%     relax 10 times (post-smoothing) 
      Aout = relax_Diff_Om(Asmooth,f,Psi,dt,10,bcflag);

    end

%   impose boundary conditions
    Aout = bc_Om(Aout,Psi,bcflag);

