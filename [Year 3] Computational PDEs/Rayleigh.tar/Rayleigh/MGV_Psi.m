function Aout = MGV_Psi(Ain,f)

%=====================================================
%
% geometric multigrid V-cycle for Psi Poisson equation
%
% (recursive definition) 
% (dimension N has to be of the form 2^k + 2) 
%
% Ain:  guessed solution (n x m)-matrix
% f:    right-hand side (n x m)-matrix
%
%=====================================================

    % resolution
    n = size(f,1); 
    m = size(f,2);  

% if we are at the coarsest level
    if ((n==4)|(m==4)) 
      Aout = relax_Psi(Ain,f,10); 
    else
% otherwise

%     relax 10 times (pre-smoothing)
      Asmooth = relax_Psi(Ain,f,10); 

%     compute the residual
      res  = residual_Psi(Asmooth,f); 

%     restrict the residual to the next-coarser grid
      res2 = restrict(res); 
      res2 = bc_Psi(res2);

%     solve the error equation on the next-coarser grid by MGV
      err = MGV_Psi(zeros(size(res2)),res2); 

%     add the prolongated error to the solution 
      err = bc_Psi(err);
      Asmooth = Asmooth + prolong(err); 

%     relax 10 times (post-smoothing) 
      Aout = relax_Psi(Asmooth,f,10);

    end

    % impose boundary conditions
    Aout = bc_Psi(Aout);
