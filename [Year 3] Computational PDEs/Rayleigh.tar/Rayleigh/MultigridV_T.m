function Aout = MultigridV_T(Ain,f,dt,Nmax)

%------------------------------------------------------------------
% Multigrid V-cycle for Diffusion equation
%
% (recursive definition) 
% (dimension N has to be of the form 2^k + 2) 
%
% Ain:  guessed solution (n x m)-matrix
% f:    right-hand side (n x m)-matrix
% dt:   time-step 
% Nmax: N for finest grid - use real bcs for T, not residuals
%
%------------------------------------------------------------------

    N = size(f,1); 
    M = size(f,2);  

    if (N == Nmax)     % set the boundary condition flag 
      bcflag = 1;      % for top level equations (inhomogeneous)
    else
      bcflag = 0;      % for error equations (homogeneous)
    end

% if we are at the coarsest grid use GS, impose bc and exit
    if ((N==4)|(M==4)) 
      Aout = GS_T(Ain,f,dt,10,bcflag); 
    else
%   else

%     Use GW 10 times (pre-smoothing)
      Asmooth = GS_T(Ain,f,dt,10,bcflag); 

%     compute the residual
      res  = residual_T(Asmooth,f,dt,bcflag); 

%     restrict the residual to the next-coarser grid
      res2 = restrict(res); 
      res2 = bc_T(res2,0);

%     solve the error equation on the next grid by Multigrid (recursive)
      err = MultigridV_T(zeros(size(res2)),res2,dt,Nmax); 

%     add the interpolated error to the solution 
      err = bc_T(err,0);
      Asmooth = Asmooth + interp(err); 

%     relax 10 times (post-smoothing) 
      Aout = GS_T(Asmooth,f,dt,10,bcflag);

    end

%   impose boundary conditions
    Aout = bc_T(Aout,bcflag);

