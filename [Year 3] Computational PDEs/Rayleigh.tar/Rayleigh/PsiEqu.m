function Psinew = PsiEqu(Psiold,f) 

%===============================================
%
%  routine solves the streamfunction Poisson equation 
%  (with homogeneous Dirichlet boundary conditions) 
%
%===============================================

  global xLen
  global yLen

  % resolution
  n = size(f,1); 
  m = size(f,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  p = Psiold;  % initialize with previous streamfunction field 

  % start multigrid cycles
  rm = 1; 
  while (rm > 1.e-9)
    p = MGV_Psi(p,f);
    p = bc_Psi(p); 
    r = residual_Psi(p,f);
    rm = max(max(abs(r(2:n-1,2:m-1))));
  end

  p = bc_Psi(p);  % impose boundary conditions 
  Psinew = p; 

