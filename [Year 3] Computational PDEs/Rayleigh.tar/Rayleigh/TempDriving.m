function omrhs = TempDriving(T) 

%========================================
%
% compute buoyancy term 
%
%========================================

  global xLen
  global yLen
  global Ra 
  global Pr 
  global phi

  % resolution
  n = size(T,1);
  m = size(T,2); 
  dx = xLen/(n-2); 
  dy = yLen/(m-2); 

  % initialization
  T = bc_T(T,1);
  omrhs = zeros(n,m); 
  Tx = zeros(n,m); 
  Ty = zeros(n,m);   

  % temperature gradients
  Tx(2:n-1,:) = ( T(3:n,:) - T(1:n-2,:) )/(2*dx);
  Ty(:,2:m-1) = ( T(:,3:m) - T(:,1:m-2) )/(2*dy);

  % buoyancy term (fct of tilt angle)
  omrhs = Ra*Pr*(Tx*cos(phi) + Ty*sin(phi)); 
