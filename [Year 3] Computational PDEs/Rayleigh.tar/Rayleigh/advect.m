function qnew = advect(u,v,qold,dt)

%=================================================
%
% advection routine based on second-order 
% finite-volume (Lax-Wendroff) scheme 
%
% input: u,v (cell-centered) 
%        qold (cell-centered; quantity to be advected)
%        dt (time-step)
% output: qnew (advected quantity after one time-step)
%
%=================================================

  global xLen 
  global yLen 

  % resolution
  n = size(u,1);
  m = size(u,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % initialization
  f = zeros(n,m); 
  g = zeros(n,m);
  ux = zeros(n,m);
  vy = zeros(n,m);
  vx = zeros(n,m);
  uy = zeros(n,m);
  delx = zeros(n,m);
  dely = zeros(n,m);
  qnew = zeros(n,m);

% set up the flux velocities (on the edges) 
  ux(2:n-1,:) = (u(2:n-1,:)+u(1:n-2,:))/2;
  vx(2:n-1,:) = (v(2:n-1,:)+v(1:n-2,:))/2;
  uy(:,2:m-1) = (u(:,2:m-1)+u(:,1:m-2))/2;
  vy(:,2:m-1) = (v(:,2:m-1)+v(:,1:m-2))/2;

% impose boundary conditions on the advection velocities 
  [ux,vx,uy,vy] = bc_flux_vel(ux,vx,uy,vy);

  % sweep in the x-direction and compute fluxes
  for j=1:m-1 
    q1d = qold(:,j);
    u1d = ux(:,j);
    v1d = vx(:,j);
   [deladd,fadd,gadd1,gadd2] = fluxes(q1d,u1d,v1d,dx,dt);

    delx(:,j) = delx(:,j) + deladd; 
    f(:,j) = f(:,j) + fadd;    
    g(:,j) = g(:,j) + gadd1;
    g(:,j+1) = g(:,j+1) + gadd2;
  end

  % sweep in the y-direction and compute fluxes
  for i=1:n-1 
    q1d = qold(i,:);
    u1d = vy(i,:); 
    v1d = uy(i,:);
   [deladd,fadd,gadd1,gadd2] = fluxes(q1d,u1d,v1d,dy,dt);

    dely(i,:) = dely(i,:) + deladd.'; 
    g(i,:) = g(i,:) + fadd.'; 
    f(i,:) = f(i,:) + gadd1.'; 
    f(i+1,:) = f(i+1,:) + gadd2.'; 
  end

  % update the new advected quantity
  qnew(2:n-1,2:m-1) = qold(2:n-1,2:m-1) - ...
       dt/dx*( f(3:n,2:m-1) - f(2:n-1,2:m-1) + delx(2:n-1,2:m-1) ) - ...
       dt/dy*( g(2:n-1,3:m) - g(2:n-1,2:m-1) + dely(2:n-1,2:m-1) );

