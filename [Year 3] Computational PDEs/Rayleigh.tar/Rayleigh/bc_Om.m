function q = bc_Om(q,psi,bcflag); 

%------------------------------------------
% implement homogeneous Neumann boundary conditions
%------------------------------------------

  global xLen 
  global yLen 

  n  = size(q,1);
  m  = size(q,2);
  dx = xLen/(n-2); 
  dy = yLen/(m-2); 

  Psix_left = (-3*psi(2,:)   + psi(3,:)  )/dx/dx;  
  Psix_righ = (-3*psi(n-1,:) + psi(n-2,:))/dx/dx;  
  Psiy_bot  = (-3*psi(:,2)   + psi(:,3)  )/dy/dy;  
  Psiy_top  = (-3*psi(:,m-1) + psi(:,m-2))/dy/dy;  

  % bcflag needed for full equation, not
  % residual - fine grid only
  q(:,1) = -q(:,2)   + 2*bcflag*Psiy_bot;
  q(:,m) =2 -q(:,m-1) + 2*bcflag*Psiy_top;
  q(1,:) = -q(2,:)   + 2*bcflag*Psix_left;
  q(n,:) = -q(n-1,:) + 2*bcflag*Psix_righ;

  % corner elements (only needed for interpolation)
  q(1,1) = (q(1,2)+q(2,1))/2; 
  q(n,1) = (q(n-1,1)+q(n,2))/2;
  q(1,m) = (q(1,m-1)+q(2,m))/2;
  q(n,m) = (q(n-1,m)+q(n,m-1))/2;
