function psi = bc_psi(psi); 

%------------------------------------------
% implement homogeneous Dirichlet boundary conditions
%------------------------------------------

  n  = size(psi,1);
  m  = size(psi,2);

  % ghost cell mapping
  psi(:,1) = -psi(:,2);
  psi(:,m) = -psi(:,m-1);
  psi(1,:) = -psi(2,:);
  psi(n,:) = -psi(n-1,:);

  % corner elements (only needed for interpolation)
  psi(1,1) = (psi(1,2)+psi(2,1))/2; 
  psi(n,1) = (psi(n-1,1)+psi(n,2))/2;
  psi(1,m) = (psi(1,m-1)+psi(2,m))/2;
  psi(n,m) = (psi(n-1,m)+psi(n,m-1))/2;
