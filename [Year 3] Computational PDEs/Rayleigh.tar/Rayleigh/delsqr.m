function omega = delsqr(psi)

%=============================================
%
%   omega = Laplacian of psi 
%
%=============================================

  global xLen
  global yLen

  n = size(psi,1);
  m = size(psi,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  omega=zeros(n,m);
  
  % coefficients for diffusion equation
  coefx = 1/dx/dx;
  coefy = 1/dy/dy;
  coef0 = 2*(coefx + coefy); 

    for i=2:n-1
      for j=2:m-1
	omega(i,j) = (coefx*(psi(i+1,j)+psi(i-1,j)) + ...
	          coefy*(psi(i,j+1)+psi(i,j-1)) + ...
	         -coef0*psi(i,j));
      end
    end
  