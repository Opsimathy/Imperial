function x = laplacien(u)

%=============================================
%
%    Laplacian of u 
%
%=============================================

  global xLen
  global yLen

  % resolution
  n = size(u,1);
  m = size(u,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  x=zeros(n,m);
  
  % coefficients for diffusion equation
  coefx = 1/dx/dx;
  coefy = 1/dy/dy;
  coef0 = 2*(coefx + coefy); 

    for i=2:n-1
      for j=2:m-1
	x(i,j) = (coefx*(u(i+1,j)+u(i-1,j)) + ...
	          coefy*(u(i,j+1)+u(i,j-1)) + ...
	         -coef0*u(i,j));
      end
    end
  