%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
%   Rayleigh-Benard convection. Periodic in x             %
%   Identify i=1 and i=N+1                                                      %
%   Uses fractional-step method and Multigrid             %
%                                                         %
%   Streamfunction-vorticity formulation                  %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   clear

   global xLen  
   global yLen
   global Ra
   global Pr

   % domain and grid size (Height of 1 should be 2^k +1 ), Width xLen*2^k 
   xLen =  4; 
   yLen =  1;
   M    = 17; 
   N    = xLen*(M-1);   
   ipic = 30; %How many steps between pictures

   % parameters (Rayleigh number, Prandtl number)
   Ra   =  20000;
   Pr   =    .7;

   dx    = xLen/(N); 
   dy    = yLen/(M-1); 
   dt    = 0.01*min(dx,dy);
   tstep = 2000;  % number of time-steps 
   
   u  = zeros(N,M); 
   v  = zeros(N,M);
   T  = zeros(N,M);
   psi= zeros(N,M); 
   omega = zeros(N,M);
   %
   % Start with some nonuniform temperature perturbation to get things
   % moving
   T=Tinit(T);
   % or possibly an initial vorticity.
   % for iblob=1:4
   %    omega=blob(omega,(iblob-1)*xLen/4+.625,.5,.2,(-1)^iblob*20);
   %   
   %end
   
   % domain for graphical output
   x  = linspace(0,xLen,N+1);
   y  = linspace(0,yLen,M).';
   [xx,yy] = meshgrid(x,y);
  
   %
   % Let's do the the time loop again (could run until MaxTchange<epsilon)
   %
   velmax=0;
   maxTchange=1;
   for istep=1:tstep
       % Outout numbers every 25 steps
      if ((mod(istep,25)==0)|(istep==1)) 
     fprintf('time step %i out of %i, velmax= %i, maxTchange=%i\n',istep,tstep,velmax,maxTchange)
      end
      
     % advection step for temperature  
    Tadv = Richtmyer(u,v,T,dt);
     % diffusion step for temperature 
     Tnew  = Diffuse_T(Tadv,dt);
 
     maxTchange=max(max(abs(Tnew-T)))/dt;
     
     % Advection step for vorticity
     omadv = Richtmyer(u,v,omega,dt);

     % rhs for vorticity (buoyancy term)
     % Two step Adams-Bashforth for 2nd order
     td=TempDriving(T);
     % Needs kickstarting on first step
     if(istep==1)
      omrhs=td;
     else
      omrhs=1.5*td-0.5*tdold;
     end
     tdold=td;
    
     % diffusion step for vorticity 
     omnew = Diffuse_om(omadv,omrhs,psi,dt); 
     
     %  Solve Poisson equation for streamfunction
      psinew = psieqn(psi,-omnew);  

     % Derive the velocity field from the streamfunction
     [unew,vnew] = velo(psinew);

     % update all fields
     u = unew; 
     v = vnew; 
     omega = omnew; 
     T  = Tnew; 
     psi = psinew;
     % determine the maximum velocity (for CFL condition)
     umax = max(max(abs(u(1:N,1:M-1))));
     vmax = max(max(abs(v(1:N,1:M-1))));
     velmax = max(umax,vmax);
     Courant=velmax*dt/min(dx,dy);
     dtCFL = 0.8*min(dx,dy)/max(1,velmax);     
          % CFL = 0.8 Could automatically halve timestep
     if(dt>dtCFL)
         fprintf('Dangerous Courant number, %i\n',Courant);
     end
          % Contour every ipic steps
          
     if ((mod(istep,ipic)==0)|(istep==1)) 

% Velocity vector plot. Extend u to uper by adding another column. 
% Perhaps simpler to make all field variables larger from the start?
       figure(1) 
       uper=zeros(N+1,M);
       uper(1:N,:)=u(1:N,:);
       uper(N+1,:)=u(1,:);
       vper=zeros(N+1,M);
       vper(1:N,:)=v(1:N,:);
       vper(N+1,:)=v(1,:);
       quiver(xx(1:end,1:end)',yy(1:end,1:end)',... 
              uper(1:N+1,1:M),vper(1:N+1,1:M),1);
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18)
           %  Temperature contours (isotherms) 
       figure(2) 
       Tper=zeros(N+1,M);
       Tper(1:N,:)=T(1:N,:);
       Tper(N+1,:)=T(1,:);
       contourf(xx',yy',Tper(1:N+1,1:M),10,'r')
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);       
       drawnow
     end
   end
   % Final streamlines
   figure(3) 
       psiper=zeros(N+1,M);
       psiper(1:N,:)=psi(1:N,:);
       psiper(N+1,:)=psi(1,:);
       contourf(xx',yy',psiper(1:N+1,1:M),10,'r')
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);
       colorbar
       drawnow
