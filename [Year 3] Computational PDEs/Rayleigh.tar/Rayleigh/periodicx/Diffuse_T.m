function Tnew = Diffuse_T(Told,dt) 

%=======================================
%
% Take a Crank Nicolson step for pure diffusion 
% of the temperature
%
%=======================================

  T  = Told;  % use previous field as initial estimate 
  N  = size(Told,1); 
  M  = size(Told,2); 

  rhs=Told+0.5*dt*delsqr(Told);
  
  rm = 1;
  while (rm > 1e-9)
    T = MultigridV_T(T,rhs,dt,N);
    res = residual_T(T,rhs,dt,1); 
    rm = max(max(abs(res(1:N,2:M-1))));
  end

  T = bc_T(T,1);  % impose boundary conditions 
  Tnew = T;       

