function omnew = Diffuse_om(omold,omrhs,psi,dt) 

%=======================================
%
% Takes a Crank-Nicolson step for om_t=Pr*delsqr(om)+omrhs
%
%=======================================
  global Pr;
  
  om  = omold;         % use previous field as initial guess 
  N  = size(omold,1); 
  M  = size(omold,2); 

  rhs = omold+dt*omrhs+0.5*dt*Pr*delsqr(omold);  % add buoyancy term (omrhs)
 
  rm = 1;
  while (rm > 1e-9)
    om = MultigridV_om(om,rhs,psi,dt,N);
    res = residual_om(om,rhs,psi,dt,1); 
    rm = max(max(abs(res(1:N,2:M-1))));
  end
  om = bc_om(om,psi,1);  % impose boundary conditions 
  omnew = om;            % update vorticity field 

