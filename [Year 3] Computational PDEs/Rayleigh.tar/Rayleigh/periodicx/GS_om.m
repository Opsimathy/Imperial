function omegaout = GS_om(omegain,b,psi,dt,Niter,bcflag)

%=============================================
% 
%    Takes Niter Gauss-Seidel sweeps for omega-eqn
%
%=============================================

  global xLen
  global yLen
  global Pr

  N = size(b,1);
  M = size(b,2);
  dx = xLen/(N);
  dy = yLen/(M-1);

  % coefficients for diffusion equation
  rx = Pr*dt/dx/dx/2;
  ry = Pr*dt/dy/dy/2;
  r0 = 1 + 2*(rx + ry); 

  om = omegain;

  % implement boundary conditons
  om = bc_om(om,psi,bcflag);

  for k=1:Niter
    for i=1:N
        im=i-1;ip=i+1;
        if(im==0)im=N;end
        if(ip==N+1)ip=1;end
      for j=2:M-1
	om(i,j) = (rx*(om(ip,j)+om(im,j)) + ...
	          ry*(om(i,j+1)+om(i,j-1)) + ...
	          b(i,j))/r0;
      end
    end
    om = bc_om(om,psi,bcflag);
  end

  omegaout = om;
  