function psiout = GS_psi(psiin,f,Niter)

%===========================================
% 
% Takes Niter Gauss-Seidel sweeps for
% delsqr(psi)=f
%===========================================

  global xLen 
  global yLen

  N = size(f,1);
  M = size(f,2);
  dx = xLen/(N);
  dy = yLen/(M-1);

  % coefficients for Poisson equation
  rx = 1/dx/dx;
  ry = 1/dy/dy;
  r0 = 2*(rx + ry); 

  psi = psiin;

  % implement boundary conditons
  psi = bc_psi(psi);

  % iteration
  for k=1:Niter
    for i=1:N
        im=i-1;ip=i+1;
        if(im==0)im=N;end
        if(ip==N+1)ip=1;end
      for j=2:M-1
	psi(i,j) = (rx*(psi(ip,j)+psi(im,j)) + ...
	           ry*(psi(i,j+1)+psi(i,j-1)) - ...
	           f(i,j))/r0;
      end
    end
    psi = bc_psi(psi);
  end

  psiout = psi;
  