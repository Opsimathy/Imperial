%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
%   Advection-Diffusion of heat for given velocity field. %
%     Periodic in x                                       %
%   (using fractional-step method)                        %
%                                                         %
%   streamfunction-vorticity formulation                  %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   clear

   % global variables
   global xLen  
   global yLen
   global Ra
   global Pr

   % domain and grid size (Length of 1 should be 2^k + 2) 
   xLen =  5; 
   yLen =  1;
   M    = 17; 
   N    = xLen*(M-1);   

   % parameters (Rayleigh number, Prandtl number, Velocity scale)
   Ra   =  10000;
   Pr   =    0.7;
   V0   =  5000;

   dx    = xLen/(N); 
   dy    = yLen/(M-1); 
   dt    = 0.005*min(dx,dy);
   tstep = 2000;  % number of time-steps 
   

   u  = zeros(N,M); 
   v  = zeros(N,M);
   T  = zeros(N,M);
   psi= zeros(N,M); 
   omega = zeros(N,M);
   Nblob=6;
   for iblob=1:Nblob
       omega=blob(omega,(.5 +(iblob-1))*xLen/Nblob,.5,.2,(-1)^iblob*V0);
   end
   psirhs = -omega;   
   psi = psieqn(psi,psirhs);  
   [u,v] = velo(psi);
   
   % domain for graphical output
   x  = linspace(0,xLen,N+1);
   y  = linspace(0,yLen,M).';
   [xx,yy] = meshgrid(x,y);
   % Velocity vector plot 
       figure(1) 
       uper=zeros(N+1,M);
       uper(1:N,:)=u(1:N,:);
       uper(N+1,:)=u(1,:);
       vper=zeros(N+1,M);
       vper(1:N,:)=v(1:N,:);
       vper(N+1,:)=v(1,:);
       quiver(xx(1:end,1:end)',yy(1:end,1:end)',... 
              uper(1:N+1,1:M),vper(1:N+1,1:M),1);
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);
       pause(4)
   %
   % Let's do the the time loop again
   % Could run until maxchange < epsilon.
   maxchange=1;%i=1
   for i=1:tstep
     %  while(maxchange>1e-3)
    %       i=i+1;
     fprintf('time step %i out of %i\n',i,tstep)
     %maxchange

     % advection step for temperature  
     Tadv = Richtmyer(u,v,T,dt);

     % diffusion step for temperature 
     Tnew  = Diffuse_T(Tadv,dt);
     
     maxchange=max(max(abs(Tnew-T)))/dt;
     
  
     % One day include advection step for vorticity
     %omadv = advect(u,v,om,dt);

     % and diffusion step for vorticity 
     %omnew = Diffuse_om(omadv,omrhs,psi,dt);  
     
     % streamfunction Poisson equation
     %psinew = PsiEqu(psi,-omega);  

     % Derive the velocity field from the streamfunction
     %[unew,vnew] = velo(psinew);

     % update all fields
     %u = unew; 
     %v = vnew; 
     %omega = omnew; 
     T  = Tnew;
     %psi = psinew;

     % determine the maximum velocity (for CFL condition)
     umax = max(max(abs(u(1:N,1:M-1))));
     vmax = max(max(abs(v(1:N,1:M-1))));
     velmax = max(1,max(umax,vmax));
     dtCFL = 0.8*min(dx,dy)/velmax;     % CFL = 0.8
     if(dt>dtCFL)
         fprintf('Dangerous CFL\n');
     end
          % Contour every 25 steps
          
     if ((mod(i,25)==0)|(i==1)) 

      % % Velocity vector plot 
      % figure(1) 
       %quiver(xx(1:end,1:end)',yy(1:end,1:end)',... 
        %      u(2:n-1,2:m-1),v(2:n-1,2:m-1),1);
       %xis image
       %axis([0 xLen 0 yLen])
       %xlabel('x','FontSize',18)
       %ylabel('y','FontSize',18);

       %  Temperature contours (isotherms) 
       figure(2) 
       Tper=zeros(N+1,M);
       Tper(1:N,:)=T(1:N,:);
       Tper(N+1,:)=T(1,:);
       contourf(xx',yy',Tper(1:N+1,1:M),10,'r')
       axis image
       axis([0 xLen 0 yLen])
       xlabel('x','FontSize',18)
       ylabel('y','FontSize',18);
       
       drawnow
     end
   end
