function Aout = MultigridV_om(Ain,f,psi,dt,Nmax)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Multigrid V-cycle for Diffusion equation                     %
%`                                                             %
% (recursive definition)                                       %
% (dimension M has to be of the form 2^k+1 )                   %
%                                                              %
% Ain:  guessed solution (N x M)-matrix                        %
% f:    right-hand side (N x M)-matrix                         %
% dt:   time-step                                              %
% Nmax: N for finest grid                                      %
%                                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    N = size(f,1); 
    M = size(f,2);  

    if (N == Nmax)     % set the boundary condition flag 
      bcflag = 1;      % for top level equations (inhomogeneous)
    else
      bcflag = 0;      % for error equations (homogeneous)
    end

% if we are at the coarsest level
    if ((N==2)|(M==3)) 
      Aout = GS_om(Ain,f,psi,dt,10,bcflag); 
    else
% else

%     GS 10 times (pre-smoothing)
      Asmooth = GS_om(Ain,f,psi,dt,10,bcflag); 

%     compute the residual
      res  = residual_om(Asmooth,f,psi,dt,bcflag); 

%     restrict the residual to the next-coarser grid
      res2 = restrict(res); 
      psi2 = restrict(psi);
      res2 = bc_om(res2,psi2,0);

%     solve recursively for error on the next-coarser grid by Multigrid
      err = MultigridV_om(zeros(size(res2)),res2,psi2,dt,Nmax); 

%     add the interpolated error to the solution 
      err = bc_om(err,psi2,0);
      Asmooth = Asmooth + interp(err); 

%     Use GS 10 times more (post-smoothing) 
      Aout = GS_om(Asmooth,f,psi,dt,10,bcflag);

    end

%   impose boundary conditions
    Aout = bc_om(Aout,psi,bcflag);

