function Qnew = Richtmyer(u,v,Qold,dt)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                 %
% advection routine based on Richtmyer's second-order             %
% Lax-Wendroff scheme                                             %
% Q is at (i,j) Qpp at (i+1/2,j+1/2) Qxp is Q(i+1/2,j)            %
% Qyp is Q(i,j+1/2)    i=0 identified with i=N (periodic in x)    %
%  Qold is quantity to be advected by u,v at integer pts          %
%  dt (time-step); Qxp/Qyp at half integer time step              %
% output: Qnew advected Q after complete time-step.               %
%                                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen 
  global yLen 

  N = size(u,1);
  M = size(u,2);
  dx = xLen/(N);
  dy = yLen/(M-1);
  sx=dt/dx; sy=dt/dy;

  F = zeros(N,M); 
  G = zeros(N,M);
  Fpp=zeros(N,M-1);
  Gpp=zeros(N,M-1);
  uxp = zeros(N,M);
  vyp = zeros(N,M-1);
  vxp = zeros(N,M);
  uyp = zeros(N,M-1);
  upp=zeros(N,M-1);
  vpp=zeros(N,M-1);
  Fxp= zeros(N,M);
  %Fyp= zeros(N,M-1);% Not needed
  Gyp = zeros(N,M-1);
 % Gxp = zeros(N,M); % Not needed
  Qnew = zeros(N,M);
  Qppold=zeros(N,M-1);
  %Qppnew = zeros(N,M); % Not needed
  Qxp=zeros(N,M);
  Qyp=zeros(N,M-1);
%  
% Find Qpp,upp,vpp at integer + half grid points by local averaging
% 
  Qppold(1:N-1,1:M-1)=.25*(Qold(1:N-1,1:M-1)+Qold(2:N,1:M-1)...
         +Qold(1:N-1,2:M)+Qold(2:N,2:M));
     Qppold(N,1:M-1)=.25*(Qold(N,1:M-1)+Qold(1,1:M-1)...
         +Qold(N,2:M)+Qold(1,2:M));
  upp(1:N-1,1:M-1)=(u(1:N-1,1:M-1)+u(1:N-1,2:M)+u(2:N,1:M-1)+u(2:N,2:M))*.25;
    upp(N,1:M-1)=(u(N,1:M-1)+u(N,2:M)+u(1,1:M-1)+u(1,2:M))*.25;
  vpp(1:N-1,1:M-1)=(v(1:N-1,1:M-1)+v(1:N-1,2:M)+v(2:N,1:M-1)+v(2:N,2:M))*.25;
    vpp(N,1:M-1)=(v(N,1:M-1)+v(N,2:M)+v(1,1:M-1)+v(1,2:M))*.25;
    
     % set up the velocities at the half-points - periodic in x
  uxp(1:N-1,:) = (u(2:N,:)+u(1:N-1,:))/2;
     uxp(N,:)= (u(1,:)+u(N,:))/2;
  vxp(1:N-1,:) = (v(2:N,:)+v(1:N-1,:))/2;
     vxp(N,:)= (v(1,:)+v(N,:))/2;
  uyp(:,1:M-1) = (u(:,2:M)+u(:,1:M-1))/2;
  vyp(:,1:M-1) = (v(:,2:M)+v(:,1:M-1))/2;

  % Define fluxes at intermediate points
  F(1:N,1:M)=Qold(1:N,1:M).*u(1:N,1:M);
  G(1:N,1:M)=Qold(1:N,1:M).*v(1:N,1:M);
  Fpp(1:N,1:M-1)=Qppold(1:N,1:M-1).*upp(1:N,1:M-1);
  Gpp(1:N,1:M-1)=Qppold(1:N,1:M-1).*vpp(1:N,1:M-1);
  %
  % First half-timestep
      Qyp(2:N,1:M-1)=.25*(Qppold(2:N,1:M-1)+Qppold(1:N-1,1:M-1)+Qold(2:N,2:M)...
          +Qold(2:N,1:M-1))-.5*(sx*(Fpp(2:N,1:M-1)-Fpp(1:N-1,1:M-1))+sy*(G(2:N,2:M)-G(2:N,1:M-1)));
      Qxp(1:N-1,2:M-1)=.25*(Qppold(1:N-1,2:M-1)+Qppold(1:N-1,1:M-2)+Qold(2:N,2:M-1)...
          +Qold(1:N-1,2:M-1))-.5*(sx*(F(2:N,2:M-1)-F(1:N-1,2:M-1))+sy*(Gpp(1:N-1,2:M-1)-Gpp(1:N-1,1:M-2)));
     % x-edges (periodic)   
             Qyp(1,1:M-1)=.25*(Qppold(1,1:M-1)+Qppold(N,1:M-1)+Qold(1,2:M)...
                +Qold(1,1:M-1))-.5*(sx*(Fpp(1,1:M-1)-Fpp(N,1:M-1))+ sy*(G(1,2:M)-G(1,1:M-1)));
             Qxp(N,2:M-1)=.25*(Qppold(N,2:M-1)+Qppold(N,1:M-2)+Qold(1,2:M-1)...
              +Qold(N,2:M-1))-.5*(sx*(F(1,2:M-1)-F(N,2:M-1))+sy*(Gpp(N,2:M-1)-Gpp(N,1:M-2)));
     % y-edges use condition that v=0=G on these walls 
          Qxp(1:N-1,1)=(Qppold(1:N-1,1)+Qold(2:N,1)...
              +Qold(1:N-1,1))/3-.5*(sx*(F(2:N,1)-F(1:N-1,1))+sy*(2*Gpp(1:N-1,1)));
          Qxp(1:N-1,M)=(Qppold(1:N-1,M-1)+Qold(2:N,M)...
              +Qold(1:N-1,M))/2-.5*(sx*(F(2:N,M)-F(1:N-1,M))+sy*(-2*Gpp(1:N-1,M-1))); 
  % Evaluate fluxes at j+1/2 points
          Fxp(1:N,1:M)=Qxp(1:N,1:M).*uxp(1:N,1:M);
          %Gxp(1:N,1:M)=Qxp(1:N,1:M).*vxp(1:N,1:M);      % Not needed
          %Fyp(1:N,1:M-1)=Qyp(1:N,1:M-1).*uyp(1:N,1:M-1);% Not needed
          Gyp(1:N,1:M-1)=Qyp(1:N,1:M-1).*vyp(1:N,1:M-1);
  % Finally, 2nd half time-step
          Qnew(2:N,2:M-1)=Qold(2:N,2:M-1)-sx*(Fxp(2:N,2:M-1)-Fxp(1:N-1,2:M-1))-sy*(Gyp(2:N,2:M-1)-Gyp(2:N,1:M-2));
            Qnew(1,2:M-1)=Qold(1,2:M-1)-sx*(Fxp(1,2:M-1)-Fxp(N,2:M-1))-sy*(Gyp(1,2:M-1)-Gyp(1,1:M-2));   
  % Now y-edges G=0 on boundary
          Qnew(2:N,1)=Qold(2:N,1)-sx*(Fxp(2:N,1)-Fxp(1:N-1,1))-2*sy*(Gyp(2:N,1));
          Qnew(2:N,M)=Qold(2:N,M)-sx*(Fxp(2:N,M)-Fxp(1:N-1,M))-2*sy*(-Gyp(2:N,M-1));
  % and corners     
          Qnew(1,1)=Qold(1,1)-sx*(Fxp(1,1)-Fxp(N,1))-2*sy*(Gyp(1,1));
          Qnew(1,M)=Qold(1,M)-sx*(Fxp(1,M)-Fxp(N,M))-2*sy*(-Gyp(1,M-1));

% Not needed:      Qppnew(1:N-1,1:M-1)=Qppold(1:N-1,1:M-1)-sx*(Fyp(2:N,1:M-1)-Fyp(1:N-1,1:M-1))-sy*(Gxp(1:N-1,2:M)-Gxp(1:N-1,1:M-1));
% Not needed:         Qppnew(N,1:M-1)=Qppold(N,1:M-1)-sx*(Fyp(1,1:M-1)-Fyp(N,1:M-1))-sy*(Gxp(N,2:M)-Gxp(N,1:M-1));
