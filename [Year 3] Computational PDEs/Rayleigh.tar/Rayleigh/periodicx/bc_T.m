function T = bc_T(T,bcflag); 

%===========================================
%
% implement Dirichlet/periodic boundary conditions for Temperature
%
%===========================================

  N  = size(T,1);
  M  = size(T,2);
				% ghost cell mapping
  %T(1,:) = -T(2,:);
  %T(N,:) = T(1,:);
  for i=1:N
  T(i,1) = bcflag;%*sin(4*pi/N*(i-1)); % if bcflag=1 have heated bottom T=1
  end
  T(:,M) = 0; % cold top

  % corner elements (only needed for interpolation)
  %T(1,1) = (T(1,2)+T(2,1))/2; 
  %T(N,1) = (T(N-1,1)+T(N,2))/2;
  %T(1,M) = (T(1,M-1)+T(2,M))/2;
  %T(N,M) = (T(N-1,M)+T(N,M-1))/2;
