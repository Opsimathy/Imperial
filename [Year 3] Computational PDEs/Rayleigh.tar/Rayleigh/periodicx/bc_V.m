function v = bc_V(v); 

%===========================================
%
% implement Dirichlet boundary conditions
% (for v-velocity)
%
%===========================================

  N  = size(v,1);
  M  = size(v,2);
  
  v(:,1) = 0;
  v(:,M) = 0;

