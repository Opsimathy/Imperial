function omega = bc_om(omega,psi,bcflag); 

%------------------------------------------
% implement boundary conditions omega=-psi''
%------------------------------------------

  global xLen 
  global yLen 

  N  = size(omega,1);
  M  = size(omega,2);
  dx = xLen/(N); 
  dy = yLen/(M-1); 

  omega(:,1)  = bcflag*(-4*psi(:,2)   + 0.5*psi(:,3))/dy/dy;  
  omega(:,M)  = bcflag*(-4*psi(:,M-1) + 0.5*psi(:,M-2))/dy/dy;  
  
  % could also use less accurate -2psi(1)/dy^2

