function psinew = psieqn(psiold,f) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                              %
%  Solves delsqr(psi)=f by multigrid.          % 
%                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen
  global yLen

  N = size(f,1); 
  M = size(f,2);
  dx = xLen/(N);
  dy = yLen/(M-1);

  psi = psiold;  % initialize with previous streamfunction field 

  % start multigrid cycles
  rm = 1; 
  while (rm > 1.e-9)
    psi = MultigridV_psi(psi,f);
    psi = bc_psi(psi); 
    res = residual_psi(psi,f);
    rm = max(max(abs(res(1:N,2:M-1))));
  end

  %psi = bc_psi(psi);  % impose boundary conditions 
  psinew = psi; 

