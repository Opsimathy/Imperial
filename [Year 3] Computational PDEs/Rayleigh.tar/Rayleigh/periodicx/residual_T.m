function res = residual_T(T,f,dt,bcflag) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       %
%  residual for T_t=delsqr(T) using Crank-Nicolson      %
%  if bcflag=1, use full bcs; otherwise homogeneous     %
%                                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   global xLen
   global yLen 

   n = size(f,1);
   m = size(f,2);
   dx = xLen/(n);
   dy = yLen/(m-1);

   % coefficients for the diffusion equation
   rx = dt/dx/dx/2;
   ry = dt/dy/dy/2;
   r0 = 1 + 2*(rx + ry); 

   % impose boundary conditions
   T = bc_T(T,bcflag);

   % residual res=f-delsqr(T)
   res = zeros(size(T));
   for i=1:n
       im=i-1;ip=i+1;
       if(im==0)im=n;end
       if(ip==n+1)ip=1;end
   res(i,2:m-1) = f(i,2:m-1) - ...
                      T(i,2:m-1)*r0 + ... 
                     (T(i,3:m) + T(i,1:m-2))*ry + ... 
                     (T(ip,2:m-1) + T(im,2:m-1))*rx; 
   end


