function res = residual_om(omegain,f,psi,dt,bcflag) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                %
%  residual routine for omega diffusion equation %
%                                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   global xLen
   global yLen 
   global Pr

   N = size(f,1);
   M = size(f,2);
   dx = xLen/(N);
   dy = yLen/(M-1);

   % coefficients for the (Crank-Nicolson) diffusion equation
   rx = Pr*dt/dx/dx/2;
   ry = Pr*dt/dy/dy/2;
   r0 = 1 + 2*(rx + ry); 

   % implement boundary conditions
   omegain = bc_om(omegain,psi,bcflag);

   res = zeros(size(omegain)); 
   res(2:N-1,2:M-1) = f(2:N-1,2:M-1) - ...
                      omegain(2:N-1,2:M-1)*r0 + ... 
                     (omegain(2:N-1,3:M) + omegain(2:N-1,1:M-2))*ry + ... 
                     (omegain(3:N,2:M-1) + omegain(1:N-2,2:M-1))*rx; 
   % Impose peridodicity in x              
   res(1,2:M-1)=f(1,2:M-1)-omegain(1,2:M-1)*r0+...
              (omegain(1,3:M) + omegain(1,1:M-2))*ry + ... 
              (omegain(2,2:M-1) + omegain(N,2:M-1))*rx; 

   res(N,2:M-1)=f(N,2:M-1)-omegain(N,2:M-1)*r0+...
              (omegain(N,3:M) + omegain(N,1:M-2))*ry + ... 
              (omegain(1,2:M-1) + omegain(N-1,2:M-1))*rx; 
