function coarse = restrict(fine) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  restriction routine (full weighting) 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   [r,c] = size(fine);
   N = r;
   M = c-1; 
   N2 = N/2;
   M2 = M/2;

   coarse = zeros(N2,M2+1); 
   coarse(2:N2,2:M2) =  1/4*fine(3:2:N-1, 3:2:M-1) + ...
                         1/8*fine(2:2:N-2, 3:2:M-1) + ...
                         1/8*fine(4:2:N,   3:2:M-1) + ...
                         1/8*fine(3:2:N-1, 2:2:M-2) + ...
                         1/8*fine(3:2:N-1, 4:2:M)   + ...
                         1/16*fine(2:2:N-2,2:2:M-2) + ...
                         1/16*fine(2:2:N-2,4:2:M)   + ...
                         1/16*fine(4:2:N,  2:2:M-2) + ...
                         1/16*fine(4:2:N,  4:2:M);

%   this line alone would be the simple mapping
%   coarse(2:n2,2:m2) =  fine(3:2:n-1, 3:2:m-1);


