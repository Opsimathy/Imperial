function Acoarse = restrict(Afine) 

%=====================================================
%
%  restriction routine 
%
%=====================================================

  
   N = size(Afine,1);
   M = size(Afine,2); 
   N2 = N/2;
   M2 = (M+1)/2;

   Acoarse = zeros(N2,M2); 

   % restriction operation
   for i=2:N2
     for j=2:M2
       Acoarse(i,j) = (Afine(2*i-2,2*j-2) + ...
	               Afine(2*i-1,2*j-2) + ... 
	               Afine(2*i-2,2*j-1) + ... 
	               Afine(2*i-1,2*j-1))/4; 
     end
   end
