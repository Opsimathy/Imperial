function [u,v] = velo(psi);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                          %
%  computes the velocity field             %
%  from the streamfunction                 %
%          (Periodic in x).                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  global xLen 
  global yLen 

  N = size(psi,1);
  M = size(psi,2);
  dx = xLen/(N);
  dy = yLen/(M-1);

  % u= psi_y
  u = zeros(N,M);
  u(:,2:M-1) = (psi(:,3:M) - psi(:,1:M-2))/(2*dy);

  % v=-psi_x
  v = zeros(N,M);
  for i=1:N
      im=i-1;ip=i+1;
      if(im==0)im=N;end
      if(ip==N+1)ip=1;end
      v(i,:) = ( psi(im,:) - psi(ip,:) )/(2*dx);
  end

  % impose boundary conditions
  u = bc_U(u);
  v = bc_V(v);
  