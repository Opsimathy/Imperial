function Afine = prolong(Acoarse)

%====================================================
%
%  prolongation routine (for cell-centered quantities) 
%
%====================================================

   % resolution
   n = size(Acoarse,1); 
   m = size(Acoarse,2); 
   n2 = 2*(n-2) + 2;
   m2 = 2*(m-2) + 2; 

   Afine = zeros(n2,m2);

   % prolongation operation
   for i=1:n-1
     for j=1:m-1
       ifine = 2*i-1;
       jfine = 2*j-1;
       Afine(ifine,jfine) = 9/16*Acoarse(i,j) + ...
                            3/16*Acoarse(i+1,j) + ...
                            3/16*Acoarse(i,j+1) + ...
                            1/16*Acoarse(i+1,j+1);
       Afine(ifine+1,jfine) = 3/16*Acoarse(i,j) + ...
                              9/16*Acoarse(i+1,j) + ...
                              3/16*Acoarse(i+1,j+1) + ...
                              1/16*Acoarse(i,j+1);
       Afine(ifine,jfine+1) = 3/16*Acoarse(i,j) + ...
                              1/16*Acoarse(i+1,j) + ...
                              9/16*Acoarse(i,j+1) + ...
                              3/16*Acoarse(i+1,j+1);
       Afine(ifine+1,jfine+1) = 1/16*Acoarse(i,j) + ...
                                3/16*Acoarse(i+1,j) + ...
                                3/16*Acoarse(i,j+1) + ...
                                9/16*Acoarse(i+1,j+1);
     end
   end  

