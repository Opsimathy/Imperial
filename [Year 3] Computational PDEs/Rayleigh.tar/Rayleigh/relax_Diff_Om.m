function x = relax_Diff_Om(xguess,b,Psi,dt,ktimes,bcflag)

%=============================================
%
%    solves the diffusion equation for u-velocity 
%    using Gauss-Seidel
%
%=============================================

  global xLen
  global yLen
  global Pr

  % resolution
  n = size(b,1);
  m = size(b,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % coefficients for diffusion equation
  coefx = Pr*dt/dx/dx/2;
  coefy = Pr*dt/dy/dy/2;
  coef0 = 1 + 2*(coefx + coefy); 

  % initialization
  u = xguess;

  % implement boundary conditons
  u = bc_Om(u,Psi,bcflag);

  % iteration
  for k=1:ktimes
    for i=2:n-1
      for j=2:m-1
	u(i,j) = (coefx*(u(i+1,j)+u(i-1,j)) + ...
	          coefy*(u(i,j+1)+u(i,j-1)) + ...
	          b(i,j))/coef0;
      end
    end
    u = bc_Om(u,Psi,bcflag);
  end

  % final solution
  x = u;
  