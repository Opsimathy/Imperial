function x = relax_Diff_T(xguess,b,dt,ktimes,bcflag)

%=============================================
%
%    solves the diffusion equation for u-velocity 
%    using Gauss-Seidel
%
%=============================================

  global xLen
  global yLen

  % resolution
  n = size(b,1);
  m = size(b,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % coefficients for diffusion equation
  coefx = dt/dx/dx/2;
  coefy = dt/dy/dy/2;
  coef0 = 1 + 2*(coefx + coefy); 

  % initialization
  u = xguess;

  % implement boundary conditons
  u = bc_T(u,bcflag);

  % iteration
  for k=1:ktimes
    for i=2:n-1
      for j=2:m-1
	u(i,j) = (coefx*(u(i+1,j)+u(i-1,j)) + ...
	          coefy*(u(i,j+1)+u(i,j-1)) + ...
	          b(i,j))/coef0;
      end
    end
    u = bc_T(u,bcflag);
  end

  % final solution
  x = u;
  