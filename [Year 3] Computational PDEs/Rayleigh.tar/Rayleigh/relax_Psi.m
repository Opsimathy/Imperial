function x = relax_Psi(xguess,b,ktimes)

%===========================================
%
% solves the Psi Poisson equation 
% using Gauss-Seidel
%
%===========================================

  global xLen 
  global yLen

  % resolution
  n = size(b,1);
  m = size(b,2);
  dx = xLen/(n-2);
  dy = yLen/(m-2);

  % coefficients for Poisson equation
  coefx = 1/dx/dx;
  coefy = 1/dy/dy;
  coef0 = 2*(coefx + coefy); 

  % initialization
  pp = xguess;

  % implement boundary conditons
  pp = bc_Psi(pp);

  % iteration
  for k=1:ktimes
    for i=2:n-1
      for j=2:m-1
	pp(i,j) = (coefx*(pp(i+1,j)+pp(i-1,j)) + ...
	           coefy*(pp(i,j+1)+pp(i,j-1)) - ...
	           b(i,j))/coef0;
      end
    end
    pp = bc_Psi(pp);
  end

  % final solution
  x = pp;
  