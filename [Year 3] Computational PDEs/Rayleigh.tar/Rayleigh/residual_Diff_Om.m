function res = residual_Diff_Om(omega,f,psi,dt,bcflag) 

%================================================
%
%  residuals for Crank-Nicolson equation 
%  res=f-(1+dt/2*delsqr)omega
%================================================

   global xLen
   global yLen 
   global Pr

   % resolution
   n = size(f,1);
   m = size(f,2);
   dx = xLen/(n-2);
   dy = yLen/(m-2);

   % coefficients for the diffusion equation (using Crank-Nicolson)
   coefx = Pr*dt/dx/dx/2;
   coefy = Pr*dt/dy/dy/2;
   coef0 = 1 + 2*(coefx + coefy); 

   % implement boundary conditions
   omega = bc_Om(omega,psi,bcflag);

   % residual computation
   res = zeros(size(omega)); 
   res(2:n-1,2:m-1) = f(2:n-1,2:m-1) - ...
                      omega(2:n-1,2:m-1)*coef0 + ... 
                     (omega(2:n-1,3:m) + omega(2:n-1,1:m-2))*coefy + ... 
                     (omega(3:n,2:m-1) + omega(1:n-2,2:m-1))*coefx; 



