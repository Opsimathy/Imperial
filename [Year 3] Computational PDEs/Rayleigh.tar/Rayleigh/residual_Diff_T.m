function res = residual_Diff_T(Ain,f,dt,bcflag) 

%================================================
%
%  residual routine for diffusion equation 
%  (u-velocity)
%
%================================================

   global xLen
   global yLen 

   % resolution
   n = size(f,1);
   m = size(f,2);
   dx = xLen/(n-2);
   dy = yLen/(m-2);

   % coefficients for the diffusion equation
   coefx = dt/dx/dx/2;
   coefy = dt/dy/dy/2;
   coef0 = 1 + 2*(coefx + coefy); 

   % implement boundary conditions
   Ain = bc_T(Ain,bcflag);

   % residual computation
   res = zeros(size(Ain)); 
   res(2:n-1,2:m-1) = f(2:n-1,2:m-1) - ...
                      Ain(2:n-1,2:m-1)*coef0 + ... 
                     (Ain(2:n-1,3:m) + Ain(2:n-1,1:m-2))*coefy + ... 
                     (Ain(3:n,2:m-1) + Ain(1:n-2,2:m-1))*coefx; 



