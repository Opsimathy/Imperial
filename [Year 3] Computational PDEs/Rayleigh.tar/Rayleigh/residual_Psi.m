function res = residual_psi(Ain,f) 

%================================================
%
%  residual routine for Psi Poisson equation 
%
%================================================

   global xLen
   global yLen 

   n = size(f,1);
   m = size(f,2);
   dx = xLen/(n-2);
   dy = yLen/(m-2);

   % coefficients for the Poisson equation
   rx = 1/dx/dx;
   ry = 1/dy/dy;
   r0 = 2*(rx + ry); 

   % implement boundary conditions
   Ain = bc_Psi(Ain);

   % residual computation
   res = zeros(size(Ain)); 
   res(2:n-1,2:m-1) = f(2:n-1,2:m-1) + ...
                      Ain(2:n-1,2:m-1)*r0 - ... 
                     (Ain(2:n-1,3:m) + Ain(2:n-1,1:m-2))*ry - ... 
                     (Ain(3:n,2:m-1) + Ain(1:n-2,2:m-1))*rx; 



