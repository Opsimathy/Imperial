function res = residual_om(omega,f,psi,dt,bcflag) 

%================================================
%
%  residuals for Crank-Nicolson vorticity equation 
%  res=f-(1+dt/2*delsqr)omega
%================================================
   global xLen
   global yLen 
   global Pr
  
   n = size(f,1);
   m = size(f,2);
   dx = xLen/(n-2);
   dy = yLen/(m-2);


   
   
   % coefficients for the diffusion equation (using Crank-Nicolson)
   rx = Pr*dt/dx/dx/2;
   ry = Pr*dt/dy/dy/2;
   r0 = 1 + 2*(rx + ry); 

   % implement boundary conditions
   omega = bc_Om(omega,psi,bcflag);

   % residual computation
   res = zeros(size(omega)); 
   res(2:n-1,2:m-1) = f(2:n-1,2:m-1) - ...
                      omega(2:n-1,2:m-1)*r0 + ... 
                     (omega(2:n-1,3:m) + omega(2:n-1,1:m-2))*ry + ... 
                     (omega(3:n,2:m-1) + omega(1:n-2,2:m-1))*rx; 



